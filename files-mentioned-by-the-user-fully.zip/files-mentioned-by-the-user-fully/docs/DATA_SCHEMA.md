# Data Model / JSON Schema

The app keeps measurement rows spreadsheet-friendly, then derives grouped measurements, editable summary totals, rate-master billing, and print pages from that single source of truth.

```json
{
  "activeProjectId": "project_1",
  "rateMaster": [
    {
      "id": "rate_1",
      "srNo": 1,
      "particular": "POP",
      "rate": 55,
      "unit": "sft"
    },
    {
      "id": "rate_2",
      "srNo": 2,
      "particular": "Groove",
      "rate": 35,
      "unit": "rft"
    }
  ],
  "projects": [
    {
      "id": "project_1",
      "code": "P1",
      "activeTab": "measurement",
      "meta": {
        "projectName": "Kandivali 1301",
        "clientName": "Kandivali",
        "siteAddress": "Kandivali",
        "flatNumber": "1301",
        "date": "2026-04-23",
        "contractorName": "JAGDISH PRASAD GUPTA",
        "contractorMobile": "9821227208",
        "subject": "Estimate for P.O.P. Work with Materials and Labour",
        "notes": "Extra charge will be charged to shift materials from Ground Floor to any other floors"
      },
      "measurements": [
        {
          "id": "m_1",
          "room": "Hall",
          "materialLocation": "POP",
          "dimension": "",
          "repeat": "",
          "materialHint": "POP"
        },
        {
          "id": "m_2",
          "room": "",
          "materialLocation": "left right wall",
          "dimension": "27'4\" x 9'0\"",
          "repeat": 2,
          "materialHint": "",
          "blockEnd": false
        },
        {
          "id": "m_3",
          "room": "",
          "materialLocation": "",
          "dimension": "",
          "repeat": "",
          "materialHint": "",
          "blockEnd": true
        }
      ],
      "summaryOverrides": {
        "cells": {
          "Hall|||POP": 661
        },
        "totals": {
          "POP": 2186.19
        },
        "roomTotals": {
          "Hall": 1034.3
        }
      },
      "rateOverrides": {
        "POP": ""
      },
      "billParticularOverrides": {
        "POP": "POP with Material"
      },
      "printSettings": {
        "includeMeasurementInFull": false
      },
      "billExtras": [
        {
          "id": "extra_1",
          "label": "Material Shifting Charge",
          "qty": "",
          "rate": "",
          "unit": "",
          "amount": 2500
        }
      ],
      "adjustments": [
        {
          "id": "adj_1",
          "type": "discount",
          "label": "Discount",
          "value": 5
        },
        {
          "id": "adj_2",
          "type": "paid",
          "label": "Paid",
          "value": 50000
        }
      ]
    }
  ]
}
```

## Derived Structures

`buildMeasurementDisplayRows(measurements)` adds UI-only subtotal rows only when a blank row has `blockEnd: true`. This marker is created by pressing Enter on the empty row after a filled measurement row, or by using the End Block button.

```json
{
  "type": "subtotal",
  "roomName": "Hall",
  "materialName": "POP",
  "total": 661,
  "lineCount": 13
}
```

`buildSummary(measurements, summaryOverrides)` derives editable pivot data:

```json
{
  "materials": ["POP", "Groove", "Ceiling"],
  "rows": [
    {
      "srNo": 1,
      "roomName": "Hall",
      "materials": {
        "POP": 661,
        "Groove": 68,
        "Ceiling": 305.3
      },
      "roomTotal": 1034.3
    }
  ],
  "totals": {
    "POP": 2186.19,
    "Groove": 269.93,
    "Ceiling": 865.51
  },
  "traces": {
    "Hall|||POP": [492, -21, -36.75, -22.17, 62.25]
  }
}
```

`buildBill(project, rateMaster)` derives rounded billing output:

```json
{
  "items": [
    {
      "particular": "POP",
      "materialName": "POP",
      "qty": 2186.19,
      "rate": 55,
      "unit": "sft",
      "amount": 120240,
      "rateSource": "rate-master"
    }
  ],
  "subTotal": 309740,
  "adjustments": [
    {
      "type": "discount",
      "label": "Discount",
      "amount": 15487,
      "signedAmount": -15487
    }
  ],
  "grandTotal": 294253
}
```

## Print Engine

Printable views are rendered separately from the screen UI:

- `billPrint(project)` for invoice-only output.
- `summaryPrint(project)` for summary-only output.
- `measurementPrint(project)` for measurement output with material-group `tbody` blocks.
- `printBundle(project)` for full bill output in this order: Final Bill, Summary, Measurement.

Print CSS uses A4 portrait with browser margins of `10mm`, a `190mm x 277mm` print content box, `break-inside: avoid` on rows/material groups, and repeated table headers.
