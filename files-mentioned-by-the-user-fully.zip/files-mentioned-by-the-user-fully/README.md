# Automated Contractor Measurement & Billing ERP

This is a local, no-install web app for the workflow shown in the reference workbook and screenshots:

Measurement Entry -> Editable Summary -> Rate Master Billing -> A4 Print / Save PDF.

## Run

Open this file directly for the easiest no-install version:

```text
standalone.html
```

Or run the module version with the tiny local server:

```powershell
node server.mjs
```

Open:

```text
http://localhost:4173
```

## Workflow

- Use project tabs by real project name. The project name is used in navigation, print pages, backups, and bill headers.
- In Measurement, typing a value in `Room` starts a new room section.
- Empty repeat cells calculate as `1` without displaying `1`.
- Press Enter on a filled row to move down. Press Enter again on the empty row to end the current material block and show its subtotal.
- Type `POP`, `Groove`, `Ceiling`, `Flooring`, `Tancha`, etc. once as a material header, then enter all location rows below it.
- Material block subtotals are explicit block-end markers, so they do not duplicate randomly while typing.
- Dimensions like `27'4" x 9'0"`, `10'6" x 8'3"`, `50'`, and `24+20+10+7+7` are parsed automatically.
- Summary is generated dynamically by room and material, with inline editable override cells and formula traces.
- Rate Master is the central quotation source. Final Bill auto-fetches rates by material name, with manual override only when needed.
- Final Bill `Particular` values are editable while `Qty` continues to come from Summary totals.
- Final Bill rounds all monetary amounts to whole rupees.
- Use Print Only Bill for client invoice PDF, Print Summary for summary-only output, Print Measurement for measurement-only output, and Print Full Bill for bill + summary + measurement.
- Full Bill excludes raw measurement pages by default; enable "Include raw measurement pages" only when needed.
- Undo/Redo works from the toolbar or with `Ctrl+Z` / `Ctrl+Y`.
- In the browser print dialog, choose "Save as PDF" for WhatsApp-ready softcopy.

## Notes

The business logic is split into `src/lib/measurements.js` and `src/lib/aggregation.js`, so it can be moved into a React + TypeScript + Zustand app later without rewriting the parser, aggregation, rate-fetching, override, or print calculations.

To rebuild the direct-open file after source edits:

```powershell
node build-standalone.mjs
```
