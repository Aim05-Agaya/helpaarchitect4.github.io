import { readFile, writeFile } from "node:fs/promises";

const files = [
  "src/lib/measurements.js",
  "src/lib/aggregation.js",
  "src/lib/storage.js",
  "src/data/defaultData.js",
  "src/app.js",
];

function stripModules(source) {
  return source
    .replace(/^\s*import[\s\S]*?;\s*/gm, "")
    .replace(/^export function /gm, "function ")
    .replace(/^export const /gm, "const ")
    .replace(/^export let /gm, "let ")
    .replace(/^export class /gm, "class ");
}

const css = await readFile("src/styles.css", "utf8");
const scripts = await Promise.all(files.map(async (file) => stripModules(await readFile(file, "utf8"))));

const html = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contractor Measurement & Billing ERP</title>
    <style>${css}</style>
  </head>
  <body>
    <div id="app"></div>
    <script>
${scripts.join("\n\n")}
    </script>
  </body>
</html>
`;

await writeFile("standalone.html", html);
console.log("Built standalone.html");
