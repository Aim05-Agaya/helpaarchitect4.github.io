import { uid } from "../lib/measurements.js";

function row(room, materialLocation, dimension, repeat = "", materialHint = "") {
  return {
    id: uid("m"),
    room,
    materialLocation,
    dimension,
    repeat,
    materialHint,
  };
}

function blank(blockEnd = false) {
  return {
    ...row("", "", "", "", ""),
    blockEnd,
  };
}

export function createBlankProject(index = 1, options = {}) {
  const { demo = false } = options;
  const projectId = uid("project");
  const project = {
    id: projectId,
    code: `P${index}`,
    activeTab: "measurement",
    meta: {
      projectName: index === 1 ? "New Project" : `New Project ${index}`,
      clientName: "",
      siteAddress: "",
      flatNumber: "",
      date: new Date().toISOString().slice(0, 10),
      contractorName: "JAGDISH PRASAD GUPTA",
      contractorMobile: "9821227208",
      contractorSubtitle: "DECORATORS & CONTRACTORS OF PLASTER OF PARIS & GYPSUM FALSE CEILING WORKS",
      contractorAddress: "Barkat Ali Dargah Rd, Opp. Sagar Hotel, Anand Wadi, Grd Flr., 13-2-2, Gali No.1, Wadala (E), Mumbai-400 037.",
      subject: "Estimate for P.O.P. Work with Materials and Labour",
      notes: "Extra charge will be charged to shift materials from Ground Floor to any other floors",
    },
    rateOverrides: {
      POP: "",
      Ceiling: "",
      Groove: "",
      Tancha: "",
      Flooring: "",
    },
    summaryOverrides: {
      cells: {},
      totals: {},
      roomTotals: {},
    },
    billParticularOverrides: {},
    printSettings: {
      includeMeasurementInFull: false,
    },
    rates: {
      POP: 55,
      Ceiling: 125,
      Groove: 35,
      Tancha: 15,
      Flooring: 26,
    },
    billExtras: [],
    adjustments: [
      { id: uid("adj"), type: "none", label: "", value: "" },
    ],
    measurements: [],
  };

  if (!demo) {
    project.meta = {
      ...project.meta,
      clientName: "",
      siteAddress: "",
      flatNumber: "",
      subject: "Estimate for P.O.P. Work with Materials and Labour",
    };
    project.billExtras = [];
    project.adjustments = [{ id: uid("adj"), type: "none", label: "", value: "" }];
    project.measurements = Array.from({ length: 12 }, () => row("", "", "", "", ""));
    return project;
  }

  project.measurements = [
      row("Hall", "POP", "", "", "POP"),
      row("", "left right wall", `27'4" x 9'0"`, 2),
      row("", "door less", `3'0" x 7'0"`, -1),
      row("", "door less", `5'3" x 7'0"`, -1),
      row("", "less", `3'2" x 7'0"`, -1),
      row("", "khacha wall", `6'11" x 9'0"`, ""),
      row("", "khacha patta", `1'5" x 7'0"`, 2),
      row("", "window beam patta", `2'0" x 11'0"`, ""),
      row("", "taliya", `11'0" x 0'0"`, ""),
      row("", "passage beam patta", `2'0" x 4'0"`, 3),
      row("", "dhar patta", `7'0" x 0'0"`, 7),
      row("", "beam taliya", `4'0" x 1'0"`, ""),
      row("", "beam taliya", `3'5" x 0'0"`, 2),
      row("", "jhari board repairing", "50'", ""),
      blank(true),
      row("", "Groove", "", "", "Groove"),
      row("", "Groove line", "24+20+10+7+7", ""),
      blank(true),
      row("", "Ceiling", "", "", "Ceiling"),
      row("", "plane ceiling", `21'1" x 11'0"`, ""),
      row("", "cove light vertical patta", `11'1" x 0'0"`, 3),
      row("", "main door front ceiling", `6'2" x 4'1"`, ""),
      row("", "cove light vertical patta", `5'0" x 0'0"`, 3),
      blank(true),
      row("Kitchen", "POP", "", "", "POP"),
      row("", "front wall patta", `2'4" x 10'0"`, 2),
      row("", "left right wall", `7'5" x 2'4"`, 2),
      row("", "taliya", `10'0" x 1'0"`, ""),
      blank(true),
      row("", "Groove", "", "", "Groove"),
      row("", "kitchen groove", "12+9+8+6", ""),
      blank(true),
      row("", "Ceiling", "", "", "Ceiling"),
      row("", "kitchen ceiling", `9'2" x 9'9"`, ""),
    ];

  return project;
}

export function createInitialState() {
  const project = createBlankProject(1, { demo: false });
  return {
    theme: "light",
    activeProjectId: project.id,
    rateMaster: [
      { id: uid("rate"), srNo: 1, particular: "POP", rate: 55, unit: "sft" },
      { id: uid("rate"), srNo: 2, particular: "Groove", rate: 35, unit: "rft" },
      { id: uid("rate"), srNo: 3, particular: "Ceiling", rate: 125, unit: "sft" },
      { id: uid("rate"), srNo: 4, particular: "Tancha", rate: 15, unit: "rft" },
      { id: uid("rate"), srNo: 5, particular: "Flooring", rate: 26, unit: "sft" },
      { id: uid("rate"), srNo: 6, particular: "Gypsum Ceiling", rate: 125, unit: "sft" },
      { id: uid("rate"), srNo: 7, particular: "PVC Ceiling", rate: 0, unit: "job" },
    ],
    projects: [project],
  };
}
