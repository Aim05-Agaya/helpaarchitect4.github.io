import {
  adjustmentLabel,
  buildBill,
  buildMeasurementDisplayRows,
  buildSummary,
  getRateForMaterial,
} from "./lib/aggregation.js";
import { downloadJson, loadState, saveState } from "./lib/storage.js";
import { calculateArea, parseNumber, uid } from "./lib/measurements.js";
import { createBlankProject, createInitialState } from "./data/defaultData.js";

let state = normalizeState(loadState(createInitialState()));
saveState(state);
let undoStack = [];
let redoStack = [];
let pendingFocus = null;

const app = document.querySelector("#app");

function normalizeState(source) {
  const fallback = createInitialState();
  const next = {
    ...fallback,
    ...source,
    theme: source.theme || fallback.theme || "light",
    rateMaster: source.rateMaster?.length ? source.rateMaster : fallback.rateMaster,
    projects: source.projects?.length ? source.projects : fallback.projects,
  };

  next.projects = next.projects.map((project, index) => ({
    ...project,
    code: project.code || `P${index + 1}`,
    activeTab: project.activeTab || "measurement",
    meta: {
      ...fallback.projects[0].meta,
      ...project.meta,
      projectName: project.meta?.projectName || project.code || `Project ${index + 1}`,
    },
    summaryOverrides: {
      cells: {},
      totals: {},
      roomTotals: {},
      ...(project.summaryOverrides || {}),
    },
    rateOverrides: project.rateOverrides || project.rates || {},
    billParticularOverrides: project.billParticularOverrides || {},
    printSettings: {
      includeMeasurementInFull: false,
      ...(project.printSettings || {}),
    },
    billExtras: project.billExtras || project.additionalRows || [],
    adjustments: project.adjustments || (project.discount?.value
      ? [{ id: uid("adj"), type: "discount", label: "Discount", value: project.discount.value }]
      : [{ id: uid("adj"), type: "none", label: "", value: "" }]),
    measurements: project.measurements || [],
  }));

  if (!next.projects.find((project) => project.id === next.activeProjectId)) {
    next.activeProjectId = next.projects[0]?.id;
  }

  next.rateMaster = next.rateMaster.map((item, index) => ({
    id: item.id || uid("rate"),
    srNo: item.srNo || index + 1,
    particular: item.particular || "",
    rate: item.rate ?? "",
    unit: item.unit || "sft",
  }));

  return next;
}

function setState(updater, options = {}) {
  const { renderView = true, trackHistory = true } = options;
  const before = structuredClone(state);
  const next = typeof updater === "function" ? updater(structuredClone(state)) : updater;
  if (trackHistory && JSON.stringify(before) !== JSON.stringify(next)) {
    undoStack.push(before);
    if (undoStack.length > 120) undoStack.shift();
    redoStack = [];
  }
  state = next;
  saveState(state);
  if (renderView) render();
}

function clearHistory() {
  undoStack = [];
  redoStack = [];
}

function undo() {
  if (!undoStack.length) return;
  redoStack.push(structuredClone(state));
  state = undoStack.pop();
  saveState(state);
  render();
}

function redo() {
  if (!redoStack.length) return;
  undoStack.push(structuredClone(state));
  state = redoStack.pop();
  saveState(state);
  render();
}

function getActiveProject() {
  return state.projects.find((project) => project.id === state.activeProjectId) || state.projects[0];
}

function updateActiveProject(updater, options = {}) {
  setState((draft) => {
    const index = draft.projects.findIndex((project) => project.id === draft.activeProjectId);
    draft.projects[index] = updater(draft.projects[index]);
    return draft;
  }, options);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatNumber(value, digits = 2) {
  const numeric = parseNumber(value, 0);
  if (!Number.isFinite(numeric)) return "";
  return numeric.toLocaleString("en-IN", {
    minimumFractionDigits: numeric % 1 === 0 ? 0 : digits,
    maximumFractionDigits: digits,
  });
}

function formatMoney(value) {
  const numeric = Math.round(parseNumber(value, 0));
  return `&#8377; ${numeric.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`;
}

function input(attrs = {}) {
  const { className = "", value = "", dataset = {}, ...rest } = attrs;
  const dataAttrs = Object.entries(dataset).map(([key, val]) => `data-${dataName(key)}="${escapeHtml(val)}"`).join(" ");
  const attrString = Object.entries(rest)
    .map(([key, val]) => val === true ? key : `${key}="${escapeHtml(val)}"`)
    .join(" ");
  return `<input class="${className}" value="${escapeHtml(value)}" ${dataAttrs} ${attrString} />`;
}

function select(attrs = {}, options = []) {
  const { className = "", value = "", dataset = {}, ...rest } = attrs;
  const dataAttrs = Object.entries(dataset).map(([key, val]) => `data-${dataName(key)}="${escapeHtml(val)}"`).join(" ");
  const attrString = Object.entries(rest)
    .map(([key, val]) => val === true ? key : `${key}="${escapeHtml(val)}"`)
    .join(" ");
  return `
    <select class="${className}" ${dataAttrs} ${attrString}>
      ${options.map((option) => `
        <option value="${escapeHtml(option.value)}" ${String(option.value) === String(value) ? "selected" : ""}>${escapeHtml(option.label)}</option>
      `).join("")}
    </select>
  `;
}

function textarea(attrs = {}) {
  const { className = "", value = "", dataset = {}, ...rest } = attrs;
  const dataAttrs = Object.entries(dataset).map(([key, val]) => `data-${dataName(key)}="${escapeHtml(val)}"`).join(" ");
  const attrString = Object.entries(rest)
    .map(([key, val]) => val === true ? key : `${key}="${escapeHtml(val)}"`)
    .join(" ");
  return `<textarea class="${className}" ${dataAttrs} ${attrString}>${escapeHtml(value)}</textarea>`;
}

function dataName(key) {
  return String(key).replace(/[A-Z]/g, (match) => `-${match.toLowerCase()}`);
}

function projectName(project) {
  return project.meta.projectName || project.meta.clientName || project.meta.siteAddress || "Untitled Project";
}

function projectShell(project) {
  const tab = project.activeTab || "measurement";
  const themeIcon = state.theme === "dark" ? "☀" : "☾";
  const sideTabs = [
    ["measurement", "Measurement"],
    ["summary", "Summary"],
    ["final", "Final Bill"],
    ["schema", "JSON"],
  ];
  return `
    <header class="topbar no-print">
      <div>
        <p class="eyebrow">Automated Contractor ERP</p>
        <h1>${escapeHtml(projectName(project))}</h1>
      </div>
      <div class="system-toolbar" aria-label="System controls">
        <button class="tool-btn" data-action="undo" title="Undo (Ctrl + Z)" aria-label="Undo">↶</button>
        <button class="tool-btn" data-action="redo" title="Redo (Ctrl + Y)" aria-label="Redo">↷</button>
        <button class="tool-btn" data-action="export-json" title="Export full app JSON" aria-label="Export full app JSON">{ }</button>
        <button class="tool-btn" data-action="toggle-theme" title="Toggle dark and light theme" aria-label="Toggle dark and light theme">${themeIcon}</button>
        <button class="tool-btn primary" data-action="print-active" title="Print current page" aria-label="Print current page">⎙</button>
      </div>
    </header>

    <nav class="project-tabs no-print" aria-label="Projects">
      ${state.projects.map((item) => `
        <button class="project-tab ${item.id === project.id ? "active" : ""}" data-action="select-project" data-project-id="${item.id}">
          <span>${escapeHtml(projectName(item))}</span>
          <small>${escapeHtml([item.meta.clientName, item.meta.flatNumber].filter(Boolean).join(" / "))}</small>
        </button>
      `).join("")}
      <button class="project-tab add" data-action="add-project">+ New Project</button>
    </nav>

    <main class="workspace">
      <aside class="sidebar no-print">
        ${sideTabs.map(([key, label]) => `
          <button class="side-tab ${tab === key ? "active" : ""}" data-action="set-tab" data-tab="${key}">
            <span>${label}</span>
          </button>
        `).join("")}
      </aside>
      <section class="content">
        ${tab === "measurement" ? measurementTab(project) : ""}
        ${tab === "summary" ? summaryTab(project) : ""}
        ${tab === "final" ? finalTab(project) : ""}
        ${tab === "schema" ? schemaTab() : ""}
      </section>
    </main>
    ${printBundle(project)}
  `;
}

function measurementTab(project) {
  const displayRows = buildMeasurementDisplayRows(project.measurements);
  return `
    <section class="panel no-print">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">${escapeHtml(projectName(project))}</p>
          <h2>Measurement Entry</h2>
        </div>
        <div class="panel-actions">
          <button class="btn secondary" data-action="add-row">Add Row</button>
          <button class="btn secondary" data-action="add-blank-row">End Block</button>
          <button class="btn secondary" data-action="print-measurement">Print Measurement</button>
        </div>
      </div>

      <div class="meta-grid">
        ${metaInput("Project Name", "projectName", project.meta.projectName)}
        ${metaInput("Client Name", "clientName", project.meta.clientName)}
        ${metaInput("Site Address", "siteAddress", project.meta.siteAddress)}
        ${metaInput("Flat Number", "flatNumber", project.meta.flatNumber)}
        ${metaInput("Date", "date", project.meta.date, "date")}
        ${metaInput("Contractor", "contractorName", project.meta.contractorName)}
        ${metaInput("Mobile", "contractorMobile", project.meta.contractorMobile)}
        ${metaInput("Subject", "subject", project.meta.subject)}
      </div>

      <label class="wide-field">
        <span>Notes</span>
        ${textarea({ className: "field", value: project.meta.notes, dataset: { meta: "notes" }, rows: 2 })}
      </label>
    </section>

    <section class="sheet-card no-print">
      <div class="sheet-scroll">
        <table class="entry-sheet">
          <colgroup>
            <col class="col-room" />
            <col class="col-location" />
            <col class="col-dimension" />
            <col class="col-repeat" />
            <col class="col-area" />
            <col class="col-actions" />
          </colgroup>
          <thead>
            <tr>
              <th>Room</th>
              <th>Material / Location</th>
              <th>Dimension</th>
              <th>Repeat</th>
              <th>Area</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${displayRows.map((entry) => measurementDisplayRow(entry)).join("")}
          </tbody>
        </table>
      </div>
      <div class="hint-row">
        <span>Press Enter on a filled row to move down. Press Enter again on the empty row to end the material block and show its subtotal.</span>
      </div>
    </section>
  `;
}

function metaInput(label, key, value, type = "text") {
  return `
    <label>
      <span>${label}</span>
      ${input({ className: "field", value, type, dataset: { meta: key } })}
    </label>
  `;
}

function measurementDisplayRow(entry) {
  if (entry.type === "blank" && entry.row.blockEnd) return "";

  if (entry.type === "subtotal") {
    return `
      <tr class="subtotal-row">
        <td></td>
        <td colspan="3">${escapeHtml(entry.materialName)} subtotal</td>
        <td class="number readonly">${formatNumber(entry.total)}</td>
        <td></td>
      </tr>
    `;
  }

  const row = entry.row;
  const area = row.area ?? calculateArea(row.dimension, row.repeat);
  const rowClass = row.isBlank ? "blank-row" : row.isMaterialHeader ? "material-row" : "";

  return `
    <tr class="${rowClass}" data-row-index="${row.index}">
      <td>${input({ className: "cell-input room-cell", value: row.room, dataset: { row: row.index, field: "room" }, placeholder: "" })}</td>
      <td>${input({ className: "cell-input strong-cell", value: row.materialLocation, dataset: { row: row.index, field: "materialLocation" }, placeholder: row.isBlank ? "" : "Location or material header" })}</td>
      <td>${input({ className: "cell-input", value: row.dimension, dataset: { row: row.index, field: "dimension" }, placeholder: `27'4" x 9'0"` })}</td>
      <td>${input({ className: "cell-input number", value: row.repeat, dataset: { row: row.index, field: "repeat" }, placeholder: "" })}</td>
      <td class="number readonly">${row.isBlank || row.isMaterialHeader ? "" : formatNumber(area)}</td>
      <td class="row-actions">
        <button class="icon-btn" data-action="insert-row" data-row-index="${row.index}" title="Insert row below">+</button>
        <button class="icon-btn danger" data-action="delete-row" data-row-index="${row.index}" title="Delete row">x</button>
      </td>
    </tr>
  `;
}

function summaryTab(project) {
  const summary = buildSummary(project.measurements, project.summaryOverrides || {});
  const summaryWidth = Math.max(920, 340 + summary.materials.length * 150);
  return `
    <section class="panel no-print">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">${escapeHtml(projectName(project))}</p>
          <h2>Editable Summary</h2>
        </div>
        <div class="panel-actions">
          <button class="btn secondary" data-action="print-summary">Print Summary</button>
          <button class="btn secondary" data-action="set-tab" data-tab="final">Go to Final Bill</button>
        </div>
      </div>
    </section>

    <section class="sheet-card no-print">
      <div class="sheet-scroll">
        <table class="summary-sheet editable-summary" style="min-width: ${summaryWidth}px">
          <thead>
            <tr><th colspan="${summary.materials.length + 3}" class="summary-title">SUMMARY - ${escapeHtml(projectName(project))}</th></tr>
            <tr>
              <th>Sr No.</th>
              <th>Room</th>
              ${summary.materials.map((material) => `<th>${escapeHtml(material)}</th>`).join("")}
              <th>Room Total</th>
            </tr>
          </thead>
          <tbody>
            ${summary.rows.map((room) => `
              <tr>
                <td class="number">${room.srNo}</td>
                <td class="strong-cell">${escapeHtml(room.roomName)}</td>
                ${summary.materials.map((material) => summaryEditableCell(project, summary, room, material)).join("")}
                <td>
                  ${input({ className: "cell-input number", value: room.roomTotal || "", dataset: { summaryRoom: room.roomName } })}
                </td>
              </tr>
            `).join("")}
          </tbody>
          <tfoot>
            <tr>
              <td></td>
              <td>Total</td>
              ${summary.materials.map((material) => `
                <td>
                  ${input({ className: "cell-input number strong-cell", value: summary.totals[material] || "", dataset: { summaryTotal: material } })}
                </td>
              `).join("")}
              <td class="number">${formatNumber(summary.rows.reduce((sum, row) => sum + parseNumber(row.roomTotal, 0), 0))}</td>
            </tr>
          </tfoot>
        </table>
      </div>
      <div class="hint-row print-hidden">
        <span>Small formula traces show how each summary value was formed. Edit any cell or total to override it before billing.</span>
      </div>
    </section>
  `;
}

function summaryEditableCell(project, summary, room, material) {
  const key = `${room.roomName}|||${material}`;
  const trace = summary.traces[key] || [];
  const formula = trace.length ? `(${trace.map((value) => formatNumber(value)).join(" + ")})` : "";
  const override = project.summaryOverrides?.cells?.[key];
  const value = override !== undefined && String(override).trim() !== "" ? override : room.materials[material] || "";

  return `
    <td>
      ${input({ className: "cell-input number", value, dataset: { summaryCell: key } })}
      ${formula ? `<span class="formula-badge print-hidden" title="${escapeHtml(formula)}">fx</span>` : ""}
    </td>
  `;
}

function finalTab(project) {
  const bill = buildBill(project, state.rateMaster);

  return `
    <section class="panel no-print">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">${escapeHtml(projectName(project))}</p>
          <h2>Final Bill</h2>
        </div>
        <div class="panel-actions">
          <button class="btn secondary" data-action="add-extra">Add Bill Item</button>
          <button class="btn secondary" data-action="add-adjustment">Add Adjustment</button>
          <button class="btn primary" data-action="print-bill">Print Only Bill</button>
          <button class="btn primary" data-action="print-full">Print Full Bill</button>
        </div>
      </div>
      <label class="print-option">
        <input type="checkbox" data-print-setting="includeMeasurementInFull" ${project.printSettings?.includeMeasurementInFull ? "checked" : ""} />
        <span>Include raw measurement pages in Full Bill print</span>
      </label>
    </section>

    <section class="bill-layout no-print">
      <div class="bill-stack">
        <div class="sheet-card">
          <div class="sheet-scroll">
            <table class="bill-sheet">
              <thead>
                <tr>
                  <th>Sr. no</th>
                  <th>Particular</th>
                  <th>Qty</th>
                  <th>Rate</th>
                  <th>Amount</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                ${bill.items.map((item) => billItemRow(project, item)).join("")}
                ${project.billExtras.map((row, index) => manualExtraRow(row, bill.items.length + index + 1, index)).join("")}
              </tbody>
              <tfoot>
                <tr>
                  <td>Total</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td class="number">${formatMoney(bill.subTotal)}</td>
                  <td></td>
                </tr>
                ${project.adjustments.map((row, index) => adjustmentRow(row, index)).join("")}
                <tr class="grand-row">
                  <td></td>
                  <td></td>
                  <td></td>
                  <td>Total =</td>
                  <td class="number">${formatMoney(bill.grandTotal)}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
        ${rateMasterPanel()}
      </div>

      <div class="preview-wrap">
        ${billPrint(project, "preview-page")}
      </div>
    </section>
  `;
}

function billItemRow(project, item) {
  const overrideValue = project.rateOverrides?.[item.materialName] ?? "";
  const rateInfo = getRateForMaterial(item.particular, state.rateMaster, {});
  const sourceLabel = item.rateSource === "override"
    ? ""
    : rateInfo.source === "rate-master"
      ? ""
      : "Rate missing";

  return `
    <tr>
      <td class="number">${item.srNo}</td>
      <td>${input({ className: "cell-input strong-cell", value: item.particular, dataset: { billParticular: item.materialName }, placeholder: item.materialName })}</td>
      <td class="number">${formatNumber(item.qty)}</td>
      <td>
        ${input({ className: `cell-input number ${item.rateSource === "missing" ? "missing-rate" : ""}`, value: overrideValue, dataset: { rateOverride: item.materialName }, placeholder: item.rate ? formatNumber(item.rate, 0) : "Rate" })}
        ${sourceLabel ? `<small class="rate-source">${escapeHtml(sourceLabel)}</small>` : ""}
      </td>
      <td class="number">${formatMoney(item.amount)}</td>
      <td></td>
    </tr>
  `;
}

function manualExtraRow(row, srNo, index) {
  const qty = parseNumber(row.qty, 0);
  const rate = parseNumber(row.rate, 0);
  const amount = String(row.amount || "").trim() ? parseNumber(row.amount, 0) : Math.round(qty * rate);

  return `
    <tr>
      <td class="number">${srNo}</td>
      <td>${input({ className: "cell-input strong-cell", value: row.label, dataset: { extra: index, field: "label" }, placeholder: "Extra bill item" })}</td>
      <td>${input({ className: "cell-input number", value: row.qty, dataset: { extra: index, field: "qty" } })}</td>
      <td>${input({ className: "cell-input number", value: row.rate, dataset: { extra: index, field: "rate" } })}</td>
      <td>${input({ className: "cell-input number", value: row.amount || amount || "", dataset: { extra: index, field: "amount" }, placeholder: "Auto" })}</td>
      <td><button class="icon-btn danger" data-action="delete-extra" data-extra-index="${index}" title="Delete item">x</button></td>
    </tr>
  `;
}

function adjustmentRow(row, index) {
  if (row.type === "none") {
    return `
      <tr class="adjustment-row muted-row">
        <td></td>
        <td colspan="2">Adjustment hidden from print</td>
        <td>
          ${select({ className: "cell-select", value: row.type, dataset: { adjustment: index, field: "type" } }, adjustmentOptions())}
        </td>
        <td></td>
        <td><button class="icon-btn danger" data-action="delete-adjustment" data-adjustment-index="${index}" title="Delete adjustment">x</button></td>
      </tr>
    `;
  }

  return `
    <tr class="adjustment-row">
      <td></td>
      <td>${input({ className: "cell-input strong-cell", value: row.label || adjustmentLabel(row.type), dataset: { adjustment: index, field: "label" } })}</td>
      <td></td>
      <td>
        ${select({ className: "cell-select", value: row.type, dataset: { adjustment: index, field: "type" } }, adjustmentOptions())}
      </td>
      <td>${input({ className: "cell-input number", value: row.value, dataset: { adjustment: index, field: "value" }, placeholder: row.type === "discount" ? "%" : "Amount" })}</td>
      <td><button class="icon-btn danger" data-action="delete-adjustment" data-adjustment-index="${index}" title="Delete adjustment">x</button></td>
    </tr>
  `;
}

function adjustmentOptions() {
  return [
    { value: "none", label: "None" },
    { value: "discount", label: "Discount" },
    { value: "amountLess", label: "Amount Less" },
    { value: "paid", label: "Paid" },
  ];
}

function rateMasterPanel() {
  return `
    <section class="rate-master-card">
      <div class="panel-heading compact-heading">
        <div>
          <p class="eyebrow">Quotation Source</p>
          <h3>Rate Master</h3>
        </div>
        <div class="panel-actions">
          <button class="btn secondary" data-action="import-rates">Import CSV/JSON</button>
          <button class="btn secondary" data-action="add-rate">Add Rate</button>
          <input class="hidden-file" type="file" accept=".json,.csv,.txt" data-rate-import />
        </div>
      </div>
      <div class="sheet-scroll">
        <table class="rate-master-table">
          <thead>
            <tr>
              <th>Sr No</th>
              <th>Particular</th>
              <th>Rate</th>
              <th>Unit</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${state.rateMaster.map((item, index) => `
              <tr>
                <td class="number">${index + 1}</td>
                <td>${input({ className: "cell-input strong-cell", value: item.particular, dataset: { rateMaster: index, field: "particular" } })}</td>
                <td>${input({ className: "cell-input number", value: item.rate, dataset: { rateMaster: index, field: "rate" } })}</td>
                <td>${input({ className: "cell-input", value: item.unit, dataset: { rateMaster: index, field: "unit" } })}</td>
                <td><button class="icon-btn danger" data-action="delete-rate" data-rate-index="${index}" title="Delete rate">x</button></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </section>
  `;
}

function printBundle(project) {
  return `
    <section class="print-only print-bundle" aria-hidden="true">
      ${billPrint(project, "print-page")}
      ${summaryPrint(project)}
      ${measurementPrint(project)}
    </section>
  `;
}

function billPrint(project, extraClass = "") {
  const bill = buildBill(project, state.rateMaster);
  const formattedDate = formatProjectDate(project.meta.date);

  return `
    <article class="a4-page bill-print ${extraClass}" data-print-section="bill">
      ${printHeader(project)}
      <section class="print-meta">
        <div>
          <strong>TO,</strong>
          <span>${escapeHtml(project.meta.clientName || project.meta.siteAddress)}</span>
          ${project.meta.flatNumber ? `<span>Flat: ${escapeHtml(project.meta.flatNumber)}</span>` : ""}
          <span>Project: ${escapeHtml(projectName(project))}</span>
        </div>
        <strong>${escapeHtml(formattedDate)}</strong>
      </section>

      <h2 class="subject">Sub: ${escapeHtml(project.meta.subject)}</h2>

      <table class="print-table">
        <colgroup>
          <col class="print-col-sr" />
          <col class="print-col-particular" />
          <col class="print-col-qty" />
          <col class="print-col-rate" />
          <col class="print-col-amount" />
        </colgroup>
        <thead>
          <tr>
            <th>Sr. no</th>
            <th>Particular</th>
            <th>Qty</th>
            <th>Rate</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          ${bill.allRows.map((item) => `
            <tr>
              <td>${item.srNo}</td>
              <td>${escapeHtml(item.particular)}</td>
              <td class="number">${item.qty !== "" ? formatNumber(item.qty) : ""}</td>
              <td class="number">${item.rate !== "" ? formatNumber(item.rate, 0) : ""}</td>
              <td class="number">${formatMoney(item.amount)}</td>
            </tr>
          `).join("")}
          <tr class="total-row">
            <td>Total</td>
            <td></td>
            <td></td>
            <td></td>
            <td class="number">${formatMoney(bill.subTotal)}</td>
          </tr>
          ${bill.adjustments.map((adjustment) => `
            <tr class="adjustment-print-row">
              <td colspan="3"></td>
              <td>${escapeHtml(adjustment.isPercent ? `${adjustment.value}% ${adjustment.label}` : adjustment.label)}</td>
              <td class="number">-${formatMoney(adjustment.amount)}</td>
            </tr>
          `).join("")}
          ${bill.adjustments.length ? `
            <tr class="total-row">
              <td colspan="3"></td>
              <td>Total =</td>
              <td class="number">${formatMoney(bill.grandTotal)}</td>
            </tr>
          ` : ""}
        </tbody>
      </table>

      <footer class="print-footer">
        <p><strong>Note:</strong> ${escapeHtml(project.meta.notes)}</p>
        <p>Thanking you,</p>
        <div class="signature">
          <span>Yours faithfully</span>
          <strong>${escapeHtml(project.meta.contractorName || "JAGDISH PRASAD GUPTA")}</strong>
          <b>Proprietor</b>
        </div>
      </footer>
    </article>
  `;
}

function printHeader(project) {
  return `
    <header class="print-header">
      <div class="mobile">Mob: ${escapeHtml(project.meta.contractorMobile)}</div>
      <h1>${escapeHtml(project.meta.contractorName || "JAGDISH PRASAD GUPTA")}</h1>
      <p class="specialist">SPECIALIST IN:</p>
      <p class="subtitle">${escapeHtml(project.meta.contractorSubtitle)}</p>
      <p class="address">${escapeHtml(project.meta.contractorAddress)}</p>
    </header>
  `;
}

function summaryPrint(project) {
  const summary = buildSummary(project.measurements, project.summaryOverrides || {});
  return `
    <article class="a4-page summary-print print-page" data-print-section="summary">
      <h1 class="print-page-title">Summary - ${escapeHtml(projectName(project))}</h1>
      <table class="print-summary-table">
        <thead>
          <tr>
            <th>Sr No.</th>
            <th>Room</th>
            ${summary.materials.map((material) => `<th>${escapeHtml(material)}</th>`).join("")}
            <th>Room Total</th>
          </tr>
        </thead>
        <tbody>
          ${summary.rows.map((room) => `
            <tr>
              <td class="number">${room.srNo}</td>
              <td>${escapeHtml(room.roomName)}</td>
              ${summary.materials.map((material) => `<td class="number">${room.materials[material] ? formatNumber(room.materials[material]) : ""}</td>`).join("")}
              <td class="number">${formatNumber(room.roomTotal)}</td>
            </tr>
          `).join("")}
        </tbody>
        <tfoot>
          <tr>
            <td></td>
            <td>Total</td>
            ${summary.materials.map((material) => `<td class="number">${formatNumber(summary.totals[material])}</td>`).join("")}
            <td class="number">${formatNumber(summary.rows.reduce((sum, row) => sum + parseNumber(row.roomTotal, 0), 0))}</td>
          </tr>
        </tfoot>
      </table>
    </article>
  `;
}

function measurementPrint(project) {
  const displayRows = buildMeasurementDisplayRows(project.measurements);
  const groups = measurementPrintGroups(displayRows);

  return `
    <article class="a4-page measurement-print print-page" data-print-section="measurement">
      <h1 class="print-page-title">Measurement - ${escapeHtml(projectName(project))}</h1>
      <table class="print-measurement-table">
        <thead>
          <tr>
            <th>Room</th>
            <th>Material / Location</th>
            <th>Dimension</th>
            <th>Repeat</th>
            <th>Area</th>
          </tr>
        </thead>
        <tbody class="measurement-meta-group">
          <tr>
            <td>${escapeHtml(formatProjectDate(project.meta.date))}</td>
            <td>${escapeHtml(project.meta.siteAddress)}</td>
            <td>Flat: ${escapeHtml(project.meta.flatNumber)}</td>
            <td></td>
            <td></td>
          </tr>
        </tbody>
        ${groups.map((group) => `
          <tbody class="material-print-group">
            ${group.map((entry) => measurementPrintRow(entry)).join("")}
          </tbody>
        `).join("")}
      </table>
    </article>
  `;
}

function measurementPrintGroups(displayRows) {
  const groups = [];
  let current = [];

  displayRows.forEach((entry) => {
    if (entry.type === "blank") {
      if (current.length) groups.push(current);
      current = [];
      return;
    }

    if (entry.type === "row" && entry.row.isMaterialHeader && current.length) {
      groups.push(current);
      current = [];
    }

    current.push(entry);

    if (entry.type === "subtotal") {
      groups.push(current);
      current = [];
    }
  });

  if (current.length) groups.push(current);
  return groups;
}

function measurementPrintRow(entry) {
  if (entry.type === "subtotal") {
    return `
      <tr class="subtotal-row">
        <td></td>
        <td colspan="3">${escapeHtml(entry.materialName)} subtotal</td>
        <td class="number">${formatNumber(entry.total)}</td>
      </tr>
    `;
  }

  const row = entry.row;
  const repeatDisplay = row.repeat !== "" && parseNumber(row.repeat, 1) !== 1 ? row.repeat : "";
  return `
    <tr class="${row.isMaterialHeader ? "material-row" : ""}">
      <td>${escapeHtml(row.room || "")}</td>
      <td>${escapeHtml(row.materialLocation || "")}</td>
      <td>${escapeHtml(row.dimension || "")}</td>
      <td class="number">${escapeHtml(repeatDisplay)}</td>
      <td class="number">${row.isMaterialHeader ? "" : formatNumber(row.area)}</td>
    </tr>
  `;
}

function schemaTab() {
  const json = JSON.stringify(state, null, 2);
  return `
    <section class="panel">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">System Data</p>
          <h2>Full App JSON</h2>
        </div>
        <div class="panel-actions">
          <button class="btn secondary" data-action="export-json">Export JSON</button>
        </div>
      </div>
      <pre class="schema-block"><code>${escapeHtml(json)}</code></pre>
      <p class="schema-copy">
        This JSON contains the full app state: projects, measurements, summary overrides, billing rows, adjustments, print settings, theme, and the shared rate master.
      </p>
    </section>
  `;
}

function formatProjectDate(value) {
  const date = value ? new Date(`${value}T00:00:00`) : new Date();
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("en-GB");
}

function preparePrint(mode) {
  const project = getActiveProject();
  document.body.dataset.print = mode;
  document.body.dataset.includeMeasurement = project.printSettings?.includeMeasurementInFull ? "true" : "false";
  const previousTitle = document.title;
  const restoreTitle = () => {
    document.title = previousTitle;
    window.removeEventListener("afterprint", restoreTitle);
  };
  document.title = " ";
  window.addEventListener("afterprint", restoreTitle, { once: true });
  setTimeout(() => {
    window.print();
    setTimeout(restoreTitle, 250);
  }, 50);
}

function render() {
  const active = getActiveProject();
  document.body.dataset.theme = state.theme || "light";
  app.innerHTML = projectShell(active);
  if (pendingFocus) {
    const selector = `[data-row="${pendingFocus.row}"][data-field="${pendingFocus.field}"]`;
    const target = app.querySelector(selector);
    pendingFocus = null;
    if (target) {
      target.focus();
      if (typeof target.select === "function") target.select();
    }
  }
}

app.addEventListener("input", (event) => {
  const target = event.target;

  if (target.dataset.meta) {
    updateActiveProject((draft) => {
      draft.meta[target.dataset.meta] = target.value;
      return draft;
    }, { renderView: false });
    return;
  }

  if (target.dataset.row) {
    const rowIndex = Number(target.dataset.row);
    const field = target.dataset.field;
    updateActiveProject((draft) => {
      draft.measurements[rowIndex][field] = target.value;
      return draft;
    }, { renderView: false });
    return;
  }

  if (target.dataset.summaryCell) {
    updateActiveProject((draft) => {
      draft.summaryOverrides.cells[target.dataset.summaryCell] = target.value;
      return draft;
    }, { renderView: false });
    return;
  }

  if (target.dataset.summaryTotal) {
    updateActiveProject((draft) => {
      draft.summaryOverrides.totals[target.dataset.summaryTotal] = target.value;
      return draft;
    }, { renderView: false });
    return;
  }

  if (target.dataset.summaryRoom) {
    updateActiveProject((draft) => {
      draft.summaryOverrides.roomTotals[target.dataset.summaryRoom] = target.value;
      return draft;
    }, { renderView: false });
    return;
  }

  if (target.dataset.rateOverride) {
    updateActiveProject((draft) => {
      draft.rateOverrides[target.dataset.rateOverride] = target.value;
      return draft;
    }, { renderView: false });
    return;
  }

  if (target.dataset.billParticular) {
    updateActiveProject((draft) => {
      const material = target.dataset.billParticular;
      if (target.value.trim()) draft.billParticularOverrides[material] = target.value;
      else delete draft.billParticularOverrides[material];
      return draft;
    }, { renderView: false });
    return;
  }

  if (target.dataset.extra) {
    const rowIndex = Number(target.dataset.extra);
    const field = target.dataset.field;
    updateActiveProject((draft) => {
      draft.billExtras[rowIndex][field] = target.value;
      return draft;
    }, { renderView: false });
    return;
  }

  if (target.dataset.adjustment) {
    const rowIndex = Number(target.dataset.adjustment);
    const field = target.dataset.field;
    updateActiveProject((draft) => {
      draft.adjustments[rowIndex][field] = target.value;
      return draft;
    }, { renderView: false });
    return;
  }

  if (target.dataset.rateMaster) {
    const rowIndex = Number(target.dataset.rateMaster);
    const field = target.dataset.field;
    setState((draft) => {
      draft.rateMaster[rowIndex][field] = target.value;
      return draft;
    }, { renderView: false });
  }
});

app.addEventListener("change", (event) => {
  const target = event.target;

  if (target.dataset.rateImport !== undefined && target.files?.[0]) {
    importRateFile(target.files[0]);
    return;
  }

  if (target.dataset.adjustment) {
    const rowIndex = Number(target.dataset.adjustment);
    const field = target.dataset.field;
    updateActiveProject((draft) => {
      draft.adjustments[rowIndex][field] = target.value;
      if (field === "type" && !draft.adjustments[rowIndex].label) {
        draft.adjustments[rowIndex].label = adjustmentLabel(target.value);
      }
      return draft;
    });
    return;
  }

  if (target.dataset.printSetting) {
    updateActiveProject((draft) => {
      draft.printSettings[target.dataset.printSetting] = target.checked;
      return draft;
    });
    return;
  }

  if (
    target.dataset.meta
    || target.dataset.row
    || target.dataset.summaryCell
    || target.dataset.summaryTotal
    || target.dataset.summaryRoom
    || target.dataset.rateOverride
    || target.dataset.billParticular
    || target.dataset.extra
    || target.dataset.rateMaster
  ) {
    render();
  }
});

app.addEventListener("keydown", (event) => {
  const target = event.target;

  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
    event.preventDefault();
    undo();
    return;
  }

  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "y") {
    event.preventDefault();
    redo();
    return;
  }

  if (event.key !== "Enter" || !target.dataset.row) return;

  event.preventDefault();
  const rowIndex = Number(target.dataset.row);
  const field = target.dataset.field;

  updateActiveProject((draft) => {
    const row = draft.measurements[rowIndex];
    if (!row) return draft;
    row[field] = target.value;

    const isBlank = isMeasurementInputBlank(row);
    if (isBlank) {
      row.blockEnd = true;
      if (!draft.measurements[rowIndex + 1]) {
        draft.measurements.push({ id: uid("m"), room: "", materialLocation: "", dimension: "", repeat: "", materialHint: "" });
      }
      pendingFocus = { row: rowIndex + 1, field: "materialLocation" };
      return draft;
    }

    row.blockEnd = false;
    if (!draft.measurements[rowIndex + 1]) {
      draft.measurements.push({ id: uid("m"), room: "", materialLocation: "", dimension: "", repeat: "", materialHint: "" });
    }
    pendingFocus = { row: rowIndex + 1, field };
    return draft;
  });
});

function isMeasurementInputBlank(row) {
  return !String(row.room || "").trim()
    && !String(row.materialLocation || "").trim()
    && !String(row.dimension || "").trim()
    && !String(row.repeat || "").trim();
}

app.addEventListener("click", (event) => {
  const button = event.target.closest("button");
  if (!button) return;

  const action = button.dataset.action;
  const project = getActiveProject();

  if (action === "undo") {
    undo();
    return;
  }

  if (action === "redo") {
    redo();
    return;
  }

  if (action === "toggle-theme") {
    setState((draft) => {
      draft.theme = draft.theme === "dark" ? "light" : "dark";
      return draft;
    }, { trackHistory: false });
    return;
  }

  if (action === "select-project") {
    setState((draft) => {
      draft.activeProjectId = button.dataset.projectId;
      return draft;
    });
  }

  if (action === "add-project") {
    setState((draft) => {
      const newProject = createBlankProject(draft.projects.length + 1, { demo: false });
      draft.projects.push(newProject);
      draft.activeProjectId = newProject.id;
      return draft;
    }, { trackHistory: false });
    clearHistory();
  }

  if (action === "set-tab") {
    updateActiveProject((draft) => {
      draft.activeTab = button.dataset.tab;
      return draft;
    });
  }

  if (action === "add-row") {
    updateActiveProject((draft) => {
      draft.measurements.push({ id: uid("m"), room: "", materialLocation: "", dimension: "", repeat: "", materialHint: "" });
      return draft;
    });
  }

  if (action === "add-blank-row") {
    updateActiveProject((draft) => {
      draft.measurements.push({ id: uid("m"), room: "", materialLocation: "", dimension: "", repeat: "", materialHint: "", blockEnd: true });
      draft.measurements.push({ id: uid("m"), room: "", materialLocation: "", dimension: "", repeat: "", materialHint: "" });
      return draft;
    });
  }

  if (action === "insert-row") {
    const rowIndex = Number(button.dataset.rowIndex);
    updateActiveProject((draft) => {
      draft.measurements.splice(rowIndex + 1, 0, { id: uid("m"), room: "", materialLocation: "", dimension: "", repeat: "", materialHint: "" });
      return draft;
    });
  }

  if (action === "delete-row") {
    const rowIndex = Number(button.dataset.rowIndex);
    updateActiveProject((draft) => {
      if (draft.measurements.length > 1) draft.measurements.splice(rowIndex, 1);
      return draft;
    });
  }

  if (action === "add-extra") {
    updateActiveProject((draft) => {
      draft.billExtras.push({ id: uid("extra"), label: "", qty: "", rate: "", unit: "", amount: "" });
      return draft;
    });
  }

  if (action === "delete-extra") {
    const rowIndex = Number(button.dataset.extraIndex);
    updateActiveProject((draft) => {
      draft.billExtras.splice(rowIndex, 1);
      return draft;
    });
  }

  if (action === "add-adjustment") {
    updateActiveProject((draft) => {
      draft.adjustments.push({ id: uid("adj"), type: "none", label: "", value: "" });
      return draft;
    });
  }

  if (action === "delete-adjustment") {
    const rowIndex = Number(button.dataset.adjustmentIndex);
    updateActiveProject((draft) => {
      draft.adjustments.splice(rowIndex, 1);
      if (!draft.adjustments.length) draft.adjustments.push({ id: uid("adj"), type: "none", label: "", value: "" });
      return draft;
    });
  }

  if (action === "add-rate") {
    setState((draft) => {
      draft.rateMaster.push({ id: uid("rate"), srNo: draft.rateMaster.length + 1, particular: "", rate: "", unit: "sft" });
      return draft;
    });
  }

  if (action === "delete-rate") {
    const rowIndex = Number(button.dataset.rateIndex);
    setState((draft) => {
      draft.rateMaster.splice(rowIndex, 1);
      draft.rateMaster.forEach((item, index) => { item.srNo = index + 1; });
      return draft;
    });
  }

  if (action === "import-rates") {
    app.querySelector("[data-rate-import]")?.click();
  }

  if (action === "export-json") {
    downloadJson(state, "contractor-erp-app.json");
  }

  if (action === "reset-demo") {
    if (confirm("Restore the demo project data?")) {
      setState(createInitialState(), { trackHistory: false });
      clearHistory();
    }
  }

  if (action === "print-active") {
    const mode = project.activeTab === "summary" ? "summary" : project.activeTab === "measurement" ? "measurement" : "bill";
    preparePrint(mode);
  }

  if (action === "print-bill") preparePrint("bill");
  if (action === "print-summary") preparePrint("summary");
  if (action === "print-measurement") preparePrint("measurement");
  if (action === "print-full") preparePrint("full");
});

function importRateFile(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const content = String(reader.result || "");
      const rows = file.name.toLowerCase().endsWith(".json")
        ? JSON.parse(content)
        : parseRateCsv(content);

      if (!Array.isArray(rows)) throw new Error("Rate file must contain rows");

      setState((draft) => {
        draft.rateMaster = rows
          .filter((row) => row.particular || row.Particular)
          .map((row, index) => ({
            id: uid("rate"),
            srNo: index + 1,
            particular: row.particular || row.Particular || row.material || row.Material || "",
            rate: row.rate ?? row.Rate ?? "",
            unit: row.unit || row.Unit || "sft",
          }));
        return draft;
      });
    } catch (error) {
      alert(`Could not import rates: ${error.message}`);
    }
  };
  reader.readAsText(file);
}

function parseRateCsv(content) {
  const lines = content.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  if (!lines.length) return [];
  const headers = lines[0].split(",").map((header) => header.trim().toLowerCase());
  return lines.slice(1).map((line) => {
    const values = line.split(",").map((value) => value.trim());
    const row = {};
    headers.forEach((header, index) => {
      row[header] = values[index] || "";
    });
    return {
      particular: row.particular || row.material || row.name || values[1] || values[0],
      rate: row.rate || values[2] || values[1],
      unit: row.unit || values[3] || "sft",
    };
  });
}

render();
